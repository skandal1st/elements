# Elements Finance - Архитектура системы

**Версия:** 1.0.0  
**Дата:** 21 января 2026

[← Назад к оглавлению](./01-overview.md)

---

## 1. Общая архитектура

Elements Finance построен на **микросервисной архитектуре** с четким разделением ответственности между компонентами.

### 1.1 Архитектурная диаграмма

```
┌─────────────────────────────────────────────────────────────────┐
│                         FRONTEND LAYER                           │
│                                                                  │
│    ┌──────────────┐  ┌──────────────┐  ┌──────────────┐       │
│    │  Dashboard   │  │   Reports    │  │  Settings    │       │
│    │  Components  │  │  Components  │  │  Components  │       │
│    └──────────────┘  └──────────────┘  └──────────────┘       │
│                                                                  │
│         React 18 + TypeScript + Redux + TailwindCSS             │
└─────────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                        API GATEWAY                               │
│                                                                  │
│           FastAPI + JWT Auth + Rate Limiting                    │
│           Request Validation + Response Caching                 │
└─────────────────────────────────────────────────────────────────┘
                              ▼
        ┌──────────────────────┼──────────────────────┐
        ▼                      ▼                      ▼
┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│   Finance    │      │   Payroll    │      │  Analytics   │
│   Service    │      │   Service    │      │   Service    │
│              │      │              │      │              │
│ - Accounts   │      │ - Calculate  │      │ - Dashboard  │
│ - Transactions│     │ - Employees  │      │ - KPI        │
│ - Budgets    │      │ - Deductions │      │ - Forecast   │
│ - Receivables│      │ - Reports    │      │ - Profitabil │
│ - Payables   │      │              │      │              │
└──────────────┘      └──────────────┘      └──────────────┘
        │                      │                      │
        └──────────────────────┼──────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                         DATA LAYER                               │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │ PostgreSQL   │  │    Redis     │  │    MinIO     │         │
│  │              │  │              │  │              │         │
│  │ - Main DB    │  │ - Cache      │  │ - Files      │         │
│  │ - Relations  │  │ - Sessions   │  │ - Documents  │         │
│  │              │  │ - Pub/Sub    │  │              │         │
│  └──────────────┘  └──────────────┘  └──────────────┘         │
└─────────────────────────────────────────────────────────────────┘
                              ▼
        ┌──────────────────────┼──────────────────────┐
        ▼                      ▼                      ▼
┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│  Elements    │      │  Elements    │      │     1C       │
│     HR       │      │     Doc      │      │  Integration │
│              │      │              │      │              │
│ Employee API │      │ Document API │      │ Import/Export│
└──────────────┘      └──────────────┘      └──────────────┘
```

### 1.2 Принципы архитектуры

#### Single Responsibility
Каждый микросервис отвечает за свою область:
- **Finance Service** - основная финансовая логика
- **Payroll Service** - расчет заработной платы
- **Analytics Service** - аналитика и отчетность

#### Loose Coupling
Сервисы взаимодействуют через:
- REST API
- Message Queue (Redis Pub/Sub)
- Event-Driven архитектура

#### High Cohesion
Связанная функциональность сгруппирована в одном сервисе

#### Scalability
Каждый сервис может масштабироваться независимо

---

## 2. Технологический стек

### 2.1 Backend

| Технология | Версия | Назначение |
|------------|--------|------------|
| **Python** | 3.11+ | Основной язык backend |
| **FastAPI** | 0.109+ | Web framework (высокая производительность) |
| **SQLAlchemy** | 2.0+ | ORM для работы с БД |
| **Alembic** | 1.13+ | Миграции базы данных |
| **Pydantic** | 2.5+ | Валидация данных |
| **Celery** | 5.3+ | Асинхронные задачи |
| **Redis** | 7.2+ | Кэш, очередь сообщений, Pub/Sub |
| **pytest** | 7.4+ | Тестирование |

**Дополнительные библиотеки:**
```python
# requirements.txt
fastapi==0.109.0
uvicorn[standard]==0.27.0
sqlalchemy==2.0.25
alembic==1.13.1
pydantic==2.5.3
pydantic-settings==2.1.0
python-jose[cryptography]==3.3.0  # JWT
passlib[bcrypt]==1.7.4  # Хэширование паролей
python-multipart==0.0.6  # Загрузка файлов
celery==5.3.4
redis==5.0.1
psycopg2-binary==2.9.9  # PostgreSQL driver
openpyxl==3.1.2  # Excel
reportlab==4.0.9  # PDF
python-dateutil==2.8.2
numpy==1.26.3
pandas==2.1.4
httpx==0.26.0  # HTTP клиент
```

### 2.2 Frontend

| Технология | Версия | Назначение |
|------------|--------|------------|
| **React** | 18.2+ | UI библиотека |
| **TypeScript** | 5.3+ | Типизация |
| **Redux Toolkit** | 2.0+ | Управление состоянием |
| **React Query** | 5.17+ | Server state management |
| **TailwindCSS** | 3.4+ | Стилизация |
| **Recharts** | 2.10+ | Графики и визуализация |
| **React Hook Form** | 7.49+ | Управление формами |
| **date-fns** | 3.0+ | Работа с датами |
| **axios** | 1.6+ | HTTP клиент |

**Дополнительные библиотеки:**
```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "typescript": "^5.3.3",
    "@reduxjs/toolkit": "^2.0.1",
    "@tanstack/react-query": "^5.17.0",
    "tailwindcss": "^3.4.0",
    "recharts": "^2.10.3",
    "react-hook-form": "^7.49.3",
    "date-fns": "^3.0.6",
    "axios": "^1.6.5",
    "react-router-dom": "^6.21.1",
    "lucide-react": "^0.303.0",
    "@headlessui/react": "^1.7.17",
    "react-hot-toast": "^2.4.1",
    "zustand": "^4.4.7"
  }
}
```

### 2.3 База данных

| Система | Версия | Назначение |
|---------|--------|------------|
| **PostgreSQL** | 15+ | Основное хранилище данных |
| **Redis** | 7.2+ | Кэш, сессии, очереди |
| **MinIO** | Latest | S3-совместимое хранилище файлов |

**Расширения PostgreSQL:**
```sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";  -- UUID генерация
CREATE EXTENSION IF NOT EXISTS "pg_trgm";    -- Полнотекстовый поиск
CREATE EXTENSION IF NOT EXISTS "btree_gin";  -- Индексы для массивов
```

### 2.4 Infrastructure

| Технология | Версия | Назначение |
|------------|--------|------------|
| **Docker** | 24.0+ | Контейнеризация |
| **Docker Compose** | 2.23+ | Оркестрация dev окружения |
| **Nginx** | 1.25+ | Reverse proxy, load balancer |
| **Gunicorn** | 21.2+ | WSGI HTTP Server |
| **Supervisor** | 4.2+ | Process manager |

---

## 3. Микросервисы

### 3.1 Finance Service

**Назначение:** Основная финансовая логика

**Ответственность:**
- Управление счетами (банковские, кассы, материальные запасы)
- Транзакции (доходы, расходы, переводы)
- Платежный календарь
- Бюджеты (БДДС, БДР)
- Дебиторская/кредиторская задолженность
- Кредиты и займы
- Подотчетные средства
- Формирование ДДС

**API Endpoints:** `/api/v1/finance/*`

**База данных:**
- Таблицы: accounts, transactions, budgets, budget_items, counterparties, receivables, payables, loans, payment_calendar, accountable_amounts

**Зависимости:**
- PostgreSQL (основная БД)
- Redis (кэш)
- MinIO (документы)
- Analytics Service (передача данных для аналитики)
- Payroll Service (интеграция ЗП в транзакции)

### 3.2 Payroll Service

**Назначение:** Расчет заработной платы

**Ответственность:**
- Получение данных из Elements HR
- Расчет начислений (оклад, надбавки, премии, больничные, отпускные)
- Расчет удержаний (НДФЛ, алименты, займы)
- Расчет страховых взносов работодателя
- Формирование зарплатных ведомостей
- Экспорт в 1С Зарплата
- Передача данных обратно в Elements HR

**API Endpoints:** `/api/v1/payroll/*`

**База данных:**
- Таблицы: payroll, payroll_settings

**Зависимости:**
- Elements HR API (получение данных о сотрудниках)
- Finance Service (создание транзакций на выплату ЗП)
- 1C Integration (экспорт данных)

**Расчетные формулы:**
```python
# Оклад за месяц
salary_earned = base_salary * (worked_days / total_workdays_in_month)

# НДФЛ
taxable_income = total_accrued - tax_deductions
ndfl = taxable_income * 0.13

# Страховые взносы работодателя
pension_fund = total_accrued * 0.22
medical_insurance = total_accrued * 0.051
social_insurance = total_accrued * 0.029
injury_insurance = total_accrued * 0.002

# К выплате
net_salary = total_accrued - total_deductions
```

### 3.3 Analytics Service

**Назначение:** Аналитика, прогнозирование, отчетность

**Ответственность:**
- Dashboard с KPI
- Прогнозирование cash flow
- Рентабельность проектов
- План-факт анализ
- Формирование отчетов (Excel, PDF)
- Экспорт данных
- Визуализация данных

**API Endpoints:** `/api/v1/analytics/*`

**База данных:**
- Таблицы: analytics_cache, forecasts, project_profitability

**Зависимости:**
- Finance Service (получение финансовых данных)
- Payroll Service (получение данных по ЗП)
- Redis (кэширование расчетов)

**Методы прогнозирования:**
```python
# Простой прогноз (линейная экстраполяция)
forecast = current_balance + (avg_daily_inflow - avg_daily_outflow) * days_ahead

# Прогноз с учетом сезонности
forecast = base_trend * seasonal_factor

# Прогноз на основе платежного календаря
forecast = current_balance + sum(planned_inflows) - sum(planned_outflows)
```

---

## 4. Паттерны проектирования

### 4.1 Repository Pattern

**Назначение:** Абстракция работы с базой данных

**Структура:**
```python
# repositories/base.py
class BaseRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def get_by_id(self, id: UUID) -> Optional[Model]:
        return self.db.query(self.model).filter(self.model.id == id).first()
    
    def get_all(self, skip: int = 0, limit: int = 100) -> List[Model]:
        return self.db.query(self.model).offset(skip).limit(limit).all()
    
    def create(self, obj_in: CreateSchema) -> Model:
        db_obj = self.model(**obj_in.dict())
        self.db.add(db_obj)
        self.db.commit()
        self.db.refresh(db_obj)
        return db_obj
    
    def update(self, db_obj: Model, obj_in: UpdateSchema) -> Model:
        update_data = obj_in.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        self.db.commit()
        self.db.refresh(db_obj)
        return db_obj
    
    def delete(self, id: UUID) -> None:
        self.db.query(self.model).filter(self.model.id == id).delete()
        self.db.commit()

# repositories/transaction.py
class TransactionRepository(BaseRepository):
    model = Transaction
    
    def get_by_date_range(self, start_date: date, end_date: date) -> List[Transaction]:
        return self.db.query(Transaction)\
            .filter(Transaction.transaction_date >= start_date)\
            .filter(Transaction.transaction_date <= end_date)\
            .all()
```

### 4.2 Service Layer Pattern

**Назначение:** Бизнес-логика отделена от контроллеров

**Структура:**
```python
# services/budget_service.py
class BudgetService:
    def __init__(self, repository: BudgetRepository):
        self.repository = repository
    
    def create_budget(self, budget_data: BudgetCreate) -> Budget:
        # Бизнес-правило: только один активный бюджет типа может существовать
        active_budgets = self.repository.get_active_by_type(budget_data.budget_type)
        if active_budgets:
            raise BusinessException("Active budget of this type already exists")
        
        budget = self.repository.create(budget_data)
        
        # Событие для других сервисов
        event_bus.publish("budget.created", budget.id)
        
        return budget
    
    def calculate_plan_fact(self, budget_id: UUID) -> PlanFactReport:
        budget = self.repository.get_by_id(budget_id)
        transactions = transaction_service.get_by_budget(budget_id)
        
        # Бизнес-логика расчета
        report = self._calculate_deviations(budget, transactions)
        return report
```

### 4.3 DTO (Data Transfer Objects)

**Назначение:** Валидация и трансформация данных

**Структура:**
```python
# schemas/transaction.py
from pydantic import BaseModel, Field, validator
from decimal import Decimal
from datetime import date
from uuid import UUID

class TransactionCreate(BaseModel):
    transaction_date: date
    account_from: Optional[UUID] = None
    account_to: Optional[UUID] = None
    amount: Decimal = Field(gt=0, decimal_places=2)
    category: str = Field(min_length=1, max_length=100)
    transaction_type: str = Field(pattern="^(income|expense|transfer)$")
    payment_purpose: str = Field(min_length=1)
    
    @validator('amount')
    def amount_must_be_positive(cls, v):
        if v <= 0:
            raise ValueError('Amount must be positive')
        return v
    
    @validator('transaction_type')
    def validate_accounts_based_on_type(cls, v, values):
        if v == 'transfer':
            if not values.get('account_from') or not values.get('account_to'):
                raise ValueError('Transfer requires both accounts')
        return v

class TransactionResponse(BaseModel):
    id: UUID
    transaction_date: date
    amount: Decimal
    category: str
    status: str
    created_at: datetime
    
    class Config:
        from_attributes = True  # SQLAlchemy ORM mode
```

### 4.4 Event-Driven Architecture

**Назначение:** Асинхронная обработка событий между сервисами

**Реализация через Redis Pub/Sub:**
```python
# events/event_bus.py
class EventBus:
    def __init__(self, redis_client: Redis):
        self.redis = redis_client
    
    def publish(self, channel: str, message: dict):
        self.redis.publish(channel, json.dumps(message))
    
    def subscribe(self, channel: str, callback: Callable):
        pubsub = self.redis.pubsub()
        pubsub.subscribe(**{channel: callback})
        pubsub.run_in_thread(sleep_time=0.001)

# Использование
event_bus.publish("employee.salary_changed", {
    "employee_id": "uuid",
    "old_salary": 50000,
    "new_salary": 60000,
    "effective_date": "2026-02-01"
})

# В Finance Service подписка на события HR
def handle_salary_changed(message):
    data = json.loads(message['data'])
    # Обновить бюджет ФОТ
    budget_service.adjust_payroll_budget(data['employee_id'], data['new_salary'])

event_bus.subscribe("employee.salary_changed", handle_salary_changed)
```

### 4.5 CQRS (частично)

**Назначение:** Разделение команд (изменение данных) и запросов (чтение)

**Для аналитики используется отдельная модель чтения:**
```python
# Команда (запись)
class CreateTransaction:
    def execute(self, transaction_data: TransactionCreate):
        transaction = transaction_repository.create(transaction_data)
        # Обновить кэш аналитики
        analytics_cache.invalidate(f"transactions:{transaction.account_from}")
        return transaction

# Запрос (чтение с оптимизацией)
class GetDashboardKPI:
    def execute(self) -> DashboardKPI:
        # Читаем из кэша или материализованного представления
        cached = redis.get("dashboard:kpi")
        if cached:
            return DashboardKPI.parse_raw(cached)
        
        # Если нет в кэше - вычисляем и кэшируем
        kpi = self._calculate_kpi()
        redis.setex("dashboard:kpi", 300, kpi.json())  # 5 минут
        return kpi
```

---

## 5. Интеграции

### 5.1 Elements HR Integration

**Метод:** REST API + WebHooks

**Endpoints в Elements HR:**
```
GET  /api/v1/hr/employees            - Список сотрудников
GET  /api/v1/hr/employees/{id}       - Данные сотрудника
GET  /api/v1/hr/timesheet/{period}   - Табель
POST /webhook/payroll-calculated     - Получение данных о ЗП
```

**Endpoints в Elements Finance:**
```
POST /api/v1/hr-integration/employee-created      - Новый сотрудник
POST /api/v1/hr-integration/employee-updated      - Изменение данных
POST /api/v1/hr-integration/employee-terminated   - Увольнение
POST /api/v1/hr-integration/timesheet-updated     - Обновление табеля
```

**Аутентификация:** API Key + JWT

### 5.2 Elements Doc Integration

**Метод:** REST API

**Функциональность:**
- Хранение финансовых документов (счета, договоры, отчеты)
- ЭЦП для платежных поручений
- Автоматическое создание документов из шаблонов

**Endpoints в Elements Doc:**
```
POST /api/v1/documents              - Создать документ
GET  /api/v1/documents/{id}         - Получить документ
POST /api/v1/documents/{id}/sign    - Подписать ЭЦП
```

### 5.3 1C Integration

**Метод:** XML/CSV файлы + REST API (опционально)

**Направления интеграции:**

**Finance → 1C:**
- Выгрузка операций (проводки)
- Выгрузка контрагентов
- Выгрузка договоров

**1C → Finance:**
- Импорт банковских выписок
- Импорт справочников
- Импорт остатков

**Формат выгрузки зарплаты:**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<PayrollData>
  <Period month="1" year="2026"/>
  <Employees>
    <Employee>
      <PersonnelNumber>12345</PersonnelNumber>
      <FullName>Иванов Иван Иванович</FullName>
      <Department>IT отдел</Department>
      <Accruals>
        <Salary>47619.05</Salary>
        <Bonus>0.00</Bonus>
      </Accruals>
      <Deductions>
        <NDFL>6190.48</NDFL>
      </Deductions>
      <NetAmount>41428.57</NetAmount>
    </Employee>
  </Employees>
</PayrollData>
```

### 5.4 Bank Client Integration

**Метод:** Файлы в формате банка (обычно 1C-Client-Bank)

**Функциональность:**
- Выгрузка платежных поручений
- Импорт банковских выписок

**Формат платежного поручения (упрощенно):**
```
1CClientBankExchange
ВерсияФормата=1.03
Кодировка=Windows
Отправитель=ООО "Предприятие"

СекцияДокумент=Платежное поручение
Номер=123
Дата=21.01.2026
Сумма=150000.00
ПлательщикСчет=40702810400000001234
Плательщик=ООО "Предприятие"
ПлательщикИНН=1234567890
ПолучательСчет=40702810500000005678
Получатель=ООО "Арендодатель"
ПолучательИНН=0987654321
НазначениеПлатежа=Оплата аренды за январь 2026
КонецДокумента
```

---

## 6. Безопасность

### 6.1 Аутентификация

**JWT (JSON Web Tokens):**
```python
from jose import jwt
from datetime import datetime, timedelta

def create_access_token(user_id: UUID, expires_delta: timedelta = timedelta(hours=1)):
    to_encode = {
        "sub": str(user_id),
        "exp": datetime.utcnow() + expires_delta,
        "iat": datetime.utcnow()
    }
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_token(token: str) -> UUID:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise AuthenticationError("Invalid token")
        return UUID(user_id)
    except JWTError:
        raise AuthenticationError("Invalid token")
```

### 6.2 Авторизация (RBAC)

**Role-Based Access Control:**
```python
from enum import Enum
from functools import wraps

class Permission(Enum):
    VIEW_TRANSACTIONS = "view:transactions"
    CREATE_TRANSACTIONS = "create:transactions"
    APPROVE_BUDGETS = "approve:budgets"
    VIEW_PAYROLL = "view:payroll"
    CALCULATE_PAYROLL = "calculate:payroll"

class Role(Enum):
    ADMIN = "admin"
    FIN_DIRECTOR = "fin_director"
    CHIEF_ACCOUNTANT = "chief_accountant"
    ACCOUNTANT = "accountant"
    MANAGER = "manager"
    EMPLOYEE = "employee"

ROLE_PERMISSIONS = {
    Role.ADMIN: [p for p in Permission],  # Все права
    Role.FIN_DIRECTOR: [
        Permission.VIEW_TRANSACTIONS,
        Permission.APPROVE_BUDGETS,
        Permission.VIEW_PAYROLL
    ],
    Role.CHIEF_ACCOUNTANT: [
        Permission.VIEW_TRANSACTIONS,
        Permission.CREATE_TRANSACTIONS,
        Permission.CALCULATE_PAYROLL
    ]
}

def require_permission(permission: Permission):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, current_user: User, **kwargs):
            if permission not in ROLE_PERMISSIONS[current_user.role]:
                raise ForbiddenError("Insufficient permissions")
            return await func(*args, current_user=current_user, **kwargs)
        return wrapper
    return decorator

# Использование
@router.post("/transactions")
@require_permission(Permission.CREATE_TRANSACTIONS)
async def create_transaction(
    transaction: TransactionCreate,
    current_user: User = Depends(get_current_user)
):
    return transaction_service.create(transaction)
```

### 6.3 Шифрование

**Данные в покое (at rest):**
- PostgreSQL: Шифрование на уровне таблиц (pg_crypto)
- MinIO: Server-side encryption (SSE-S3)
- Secrets: HashiCorp Vault или зашифрованные переменные окружения

**Данные в передаче (in transit):**
- HTTPS/TLS 1.3
- WSS для WebSocket соединений

### 6.4 Аудит

**Логирование всех финансовых операций:**
```python
class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(UUID, primary_key=True, default=uuid4)
    user_id = Column(UUID, nullable=False)
    action = Column(String(50), nullable=False)  # CREATE, UPDATE, DELETE, APPROVE
    entity_type = Column(String(50), nullable=False)  # Transaction, Budget, etc.
    entity_id = Column(UUID, nullable=False)
    old_value = Column(JSONB)
    new_value = Column(JSONB)
    ip_address = Column(String(45))
    user_agent = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)

# Использование
def audit_log(action: str, entity_type: str, entity_id: UUID, old_value: dict, new_value: dict):
    log = AuditLog(
        user_id=current_user.id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        old_value=old_value,
        new_value=new_value,
        ip_address=request.client.host,
        user_agent=request.headers.get("user-agent")
    )
    db.add(log)
    db.commit()
```

---

## 7. Производительность и масштабируемость

### 7.1 Кэширование

**Redis для кэширования:**
```python
import redis
from functools import wraps

redis_client = redis.Redis(host='localhost', port=6379, db=0)

def cache_result(expiration=300):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            cache_key = f"{func.__name__}:{args}:{kwargs}"
            cached = redis_client.get(cache_key)
            
            if cached:
                return json.loads(cached)
            
            result = await func(*args, **kwargs)
            redis_client.setex(cache_key, expiration, json.dumps(result))
            return result
        return wrapper
    return decorator

# Использование
@cache_result(expiration=300)  # 5 минут
async def get_dashboard_kpi():
    return calculate_kpi()
```

**Стратегии кэширования:**
- Dashboard KPI: 5 минут
- Список счетов: 1 час
- Курсы валют: 1 день
- Справочники: 1 неделя

### 7.2 Индексы базы данных

**Критичные индексы:**
```sql
-- Транзакции
CREATE INDEX idx_transactions_date ON transactions(transaction_date);
CREATE INDEX idx_transactions_account_date ON transactions(account_from, transaction_date);
CREATE INDEX idx_transactions_category ON transactions(category);

-- Дебиторка
CREATE INDEX idx_receivables_due_date ON receivables(due_date) 
    WHERE status IN ('pending', 'partially_paid');
CREATE INDEX idx_receivables_overdue ON receivables(overdue_days) 
    WHERE overdue_days > 0;

-- Бюджеты
CREATE INDEX idx_budget_items_budget_id ON budget_items(budget_id);
CREATE INDEX idx_budget_items_category ON budget_items(category);
```

### 7.3 Асинхронные задачи (Celery)

**Тяжелые операции выполняются асинхронно:**
```python
from celery import Celery

celery_app = Celery('finance', broker='redis://localhost:6379/0')

@celery_app.task
def calculate_payroll_async(period_month: int, period_year: int):
    """Асинхронный расчет зарплаты для всех сотрудников"""
    employees = get_all_employees()
    for employee in employees:
        calculate_employee_payroll(employee.id, period_month, period_year)
    
    # Отправить уведомление по завершении
    send_notification("Payroll calculation completed")

@celery_app.task
def generate_report_async(report_type: str, params: dict):
    """Асинхронная генерация отчетов"""
    report = generate_report(report_type, params)
    # Сохранить в MinIO
    save_to_storage(report)
    # Отправить ссылку пользователю
    send_email_with_link(params['user_email'], report.url)

# Периодические задачи
@celery_app.task
def update_budget_actuals_daily():
    """Ежедневное обновление факта бюджетов"""
    active_budgets = get_active_budgets()
    for budget in active_budgets:
        update_budget_actuals(budget.id)

# Расписание
celery_app.conf.beat_schedule = {
    'update-budgets-daily': {
        'task': 'tasks.update_budget_actuals_daily',
        'schedule': crontab(hour=0, minute=0),  # Каждый день в 00:00
    },
}
```

### 7.4 Горизонтальное масштабирование

**Nginx Load Balancer:**
```nginx
upstream finance_backend {
    least_conn;
    server finance-service-1:8000;
    server finance-service-2:8000;
    server finance-service-3:8000;
}

server {
    listen 443 ssl http2;
    server_name api.elements.supporit.ru;
    
    ssl_certificate /etc/ssl/certs/elements.crt;
    ssl_certificate_key /etc/ssl/private/elements.key;
    
    location /api/v1/finance/ {
        proxy_pass http://finance_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

---

## 8. Мониторинг и логирование

### 8.1 Структурированное логирование

```python
import logging
import json
from datetime import datetime

class JSONFormatter(logging.Formatter):
    def format(self, record):
        log_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno
        }
        
        if hasattr(record, 'user_id'):
            log_data['user_id'] = record.user_id
        if hasattr(record, 'request_id'):
            log_data['request_id'] = record.request_id
            
        return json.dumps(log_data)

# Конфигурация
logging.basicConfig(level=logging.INFO)
handler = logging.StreamHandler()
handler.setFormatter(JSONFormatter())
logger = logging.getLogger("finance")
logger.addHandler(handler)

# Использование
logger.info("Transaction created", extra={
    "user_id": current_user.id,
    "transaction_id": transaction.id,
    "amount": transaction.amount
})
```

### 8.2 Метрики (Prometheus)

```python
from prometheus_client import Counter, Histogram, Gauge

# Счетчики
transactions_created = Counter(
    'finance_transactions_created_total',
    'Total number of transactions created',
    ['type', 'category']
)

api_requests = Counter(
    'finance_api_requests_total',
    'Total API requests',
    ['method', 'endpoint', 'status']
)

# Гистограммы
request_duration = Histogram(
    'finance_request_duration_seconds',
    'Request duration',
    ['endpoint']
)

# Gauge (текущие значения)
active_users = Gauge(
    'finance_active_users',
    'Number of active users'
)

# Использование
@router.post("/transactions")
async def create_transaction(transaction: TransactionCreate):
    with request_duration.labels(endpoint='/transactions').time():
        result = transaction_service.create(transaction)
        transactions_created.labels(
            type=transaction.transaction_type,
            category=transaction.category
        ).inc()
        return result
```

---

**Следующий файл:** [03-database.md](./03-database.md) - Структура базы данных
